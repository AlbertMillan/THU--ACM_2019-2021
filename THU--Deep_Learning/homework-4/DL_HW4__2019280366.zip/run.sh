python main.py --ds_path datasets/ --lr 0.001 --h1 32 --h2 64 --dr 0.0 --momentum 0.9 --save_dir model_chkpt/test_0/ --itr 20
python main.py --ds_path datasets/ --lr 0.001 --h1 32 --h2 32 --dr 0.0 --momentum 0.9 --save_dir model_chkpt/test_1/ --itr 20
python main.py --ds_path datasets/ --lr 0.001 --h1 64 --h2 64 --dr 0.0 --momentum 0.9 --save_dir model_chkpt/test_2/ --itr 20
python main.py --ds_path datasets/ --lr 0.001 --h1 32 --h2 64 --dr 0.2 --momentum 0.9 --save_dir model_chkpt/test_3/ --itr 20
python main.py --ds_path datasets/ --lr 0.001 --h1 32 --h2 64 --dr 0.0 --momentum 0.0 --save_dir model_chkpt/test_4/ --itr 20