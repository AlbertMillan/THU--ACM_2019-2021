#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import time
import pandas
sys.path.append('../')
from loglizer.models import InvariantsMiner
from loglizer import dataloader, preprocessing

#struct_log = '../data/HDFS/HDFS_100k.log_structured.csv' # The structured log file
#struct_log = '../data/HDFS/HDFS_1.log_structured.csv' # The structured log file
struct_log = '../data/HDFS/HDFS.log_structured.csv' # The structured log file
#label_file = '../data/HDFS/anomaly_label.csv' # The anomaly label file
label_file = '../data/HDFS/Label.csv' # The anomaly label file
epsilon = 0.5 # threshold for estimating invariant space

if __name__ == '__main__':


    start = time.time()

    (x_train, y_train), (x_test, y_test) = dataloader.load_HDFS(struct_log,
                                                                label_file=label_file,
                                                                window='session', 
                                                                train_ratio=0.75,
                                                                split_type='sequential')
    

    end = time.time()

    print('Loading Time: ' + str(end-start))

    feature_extractor = preprocessing.FeatureExtractor()
    x_train = feature_extractor.fit_transform(x_train)
    x_test = feature_extractor.transform(x_test)

    model = InvariantsMiner(epsilon=epsilon)
    model.fit(x_train)

    end_model = time.time()
    print('Fit Time: ' + str(end_model-end))

    print('Train validation:')
    precision, recall, f1 = model.evaluate(x_train, y_train)
    
    print('Test validation:')
    precision, recall, f1 = model.evaluate(x_test, y_test)

    benchmark_results = []
    benchmark_results.append([ precision, recall, f1, (end-start), (end_model-end), (end_model-start)])

    pd.DataFrame(benchmark_results, columns=['Precision', 'Recall', 'F1', 'Loading Time', 'Fit Time', 'Total Time']).to_csv('Results/IV_benchmark_result.csv', index=False)
