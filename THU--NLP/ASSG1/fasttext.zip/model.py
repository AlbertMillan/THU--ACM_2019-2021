import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from torch.autograd import Variable
import numpy as np
import sys

import nltk
from nltk.corpus import wordnet as wn

"""
    u_embedding: Embedding for center word.
    v_embedding: Embedding for neighbor words.
"""

def get_valid_pos_tag(tag):
    if tag.startswith('J') or tag.startswith('V') or tag.startswith('N') or tag.startswith('R'):
        return True
    return False

def cosine_similarity(a, b):
    return np.asscalar(np.dot(a, b.T)[0]) / (np.linalg.norm(a) * np.linalg.norm(b))
    

class SkipGramModel(nn.Module):
    
    def __init__(self, emb_size, emb_dimension):
        super(SkipGramModel, self).__init__()
        
        self.sense2id = dict()
        
        self.emb_size = emb_size
        self.emb_dimension = emb_dimension
        self.v_embeddings = nn.Embedding(emb_size, emb_dimension, sparse=True)
        self.u_embeddings = nn.Embedding(emb_size, emb_dimension, sparse=True)
        
#         self.sense_embeddings = nn.Embedding()
        
        initrange = 0.5 / self.emb_dimension
        init.uniform_(self.v_embeddings.weight.data, -initrange, -initrange)
        init.constant_(self.u_embeddings.weight.data, 0)
        
    
    def init_sense_embeddings(self, word2id, sim_cos_threshold=0.05):
        word_sense_master = {}
        sense_vector_list = []
        i = 0
        
        print(word2id["bear"])
        
        for (w, idx) in word2id.items():
            
            try:
                w_emb = ( self.v_embeddings(torch.LongTensor([word2id[w]])) ).cpu().data.numpy()
            except Exception:
                print("Word",w,"not found in embeddings. Skipping...")
                return None
        
            for sense in wn.lemmas(w):

                # 1. Retrieve 'gloss' from given sense in array format, each element being a sentence
                gloss = [sense.synset().definition()]
                gloss.extend(sense.synset().examples())
                word_vectors = []

                for sentence in gloss:
                    # Decomposes sentence into array of words
                    tokens = nltk.word_tokenize(sentence)
                    # Returns an array with tuples specifying the type of token, e.g. ("world","NN")
                    pos_tags = nltk.pos_tag(tokens)

                    for gloss_pos, tag in pos_tags:

                        if get_valid_pos_tag(tag):

                            try:
                                gloss_word_emb = (self.v_embeddings(torch.LongTensor([word2id[gloss_pos]]))).cpu().data.numpy()
                            except Exception:
#                                 print("Word",w,"not found in embeddings. Moving to next tag...")
                                continue

                            cos_sim = cosine_similarity(gloss_word_emb, w_emb)

                            if cos_sim > sim_cos_threshold:
                                word_vectors.append(gloss_word_emb)

                    if len(word_vectors) == 0:
                        continue
                    sense_vector = np.average(word_vectors, 0)
                    sense_vector_list.append(sense_vector)
                    self.sense2id[sense] = i
                    
                    i = i + 1
                    
                    
        self.sense_embeddings = nn.Embedding.from_pretrained(torch.FloatTensor(np.vstack(sense_vector_list)), sparse=True)
        
    
    # Here pos_u is a np.array()
    def pre_pass(self, context_u, word2id, id2word, score_margin_threshold=0.1):
        
        pos = []
        pos_vectors = {}
        word2sense = dict()
        sorted_word2senses = dict()
        valid_context = []
        
        print(context_u)
        token_context_u = [id2word[idx] for idx in context_u]
        pos_tags_input = nltk.pos_tag(token_context_u)
            
        for word, pos_tag in pos_tags_input:
            
            if get_valid_pos_tag(pos_tag):
                try:
                    pos_vectors[word] = self.v_embeddings(torch.LongTensor([word2ind[word]])).cpu().data.numpy()
                    pos.append(word)
                except Exception:
                    pass
            
        for w in pos:
            senses = wn.lemmas(w)
            senses_ids = [self.sense2id[sense] for sense in senses]
            sense_vectors = self.sense_embeddings(torch.LongTensor([senses_ids])).cpu().data.numpy()
            
            word2senses[w] = sense_vectors
            sorted_word2senses[w] = len(sense_vectors)
        
        print(sorted_word2senses)
        
        sorted_word2senses = sorted(sorted_word2senses.items(), key=lambda x: x[1])
            
        context_vec = np.average(list(pos_vectors.values()), 0)
        
        sys.exit()
        
        # (WORD SENSE DISAMBIGUATION)
        for w, n_senses in sorted_word2senses:
            if n_senses > 1:
                disambiguation_results = self.disambiguate_word_sense(w, context_vec)
                disambiguated_sense = disambiguation_results[0]

                if disambiguated_sense is None:
                    continue

                score_margin = disambiguation_results[1]
                if score_margin > score_margin_threshold:
                    # Use sense vector to replace the word vector in the context vector
                    pos_vectors[w] = self.sense_vec_coll[w][disambiguated_sense]
                    
                    context_vec = np.average(list(pos_vectors.values()), 0)
           
        
    
        
    # neg_u should correspond to the index of the negative samples sampled
    def forward(self, pos_v, pos_u, neg_u):
#         print(pos_v)
#         sys.exit()
        
        emb_v = self.v_embeddings(Variable(pos_v))
        emb_u = self.u_embeddings(Variable(pos_u))
        emb_neg_u = self.u_embeddings(Variable(neg_u))
        
        # Compute loss
        scores = torch.mul(emb_v, emb_u)
        scores = torch.sum(scores, dim=1)
        scores = F.logsigmoid(scores)
        
        neg_scores = torch.bmm(emb_neg_u, emb_v.unsqueeze(2)).squeeze()
        neg_scores = torch.sum(neg_scores, dim=1)
        neg_scores = F.logsigmoid(-neg_scores)

        return -1 * (torch.sum(scores) + torch.sum(neg_scores))
        
        
    def save_embedding(self, id2word, file_name):
        embedding = self.v_embeddings.weight.cpu().data.numpy()
        np.save("results/" + file_name, embedding)
        

    def save_to_txt(self, id2word, file_name, out_file):
        embedding = np.load("results/" + file_name)
        with open(out_file, 'w') as f:
            f.write('%d %d\n' % (len(id2word), self.emb_dimension))
            for wid, w in id2word.items():
                e = ' '.join(map(lambda x: str(x), embedding[wid]))
                f.write('%s %s\n' % (w, e))
                
                
    def load_embeddings(self, file_path):
        f = open("embeddings/"+file_path, 'r', encoding="utf-8")
#         embeddings = {}
        embeddings = []
        for line in f:
            
            split_line = line.split()
            
            if len(split_line) > 3:
            
                word = split_line[0]
                embedding = np.array([float(val) for val in split_line[1:]])

                embeddings.append(embedding)
#             sys.exit()
#             embeddings[word] = embedding
#         print(np.array(embeddings))
#         print(torch.FloatTensor(np.vstack(embeddings)).shape)
        self.v_embeddings = nn.Embedding.from_pretrained(torch.FloatTensor(np.vstack(embeddings)))
        f.close()
        